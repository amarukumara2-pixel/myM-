import { initializeApp } from 'firebase/app';
import { initializeFirestore, collection, getDocs, doc, setDoc, deleteDoc, writeBatch, limit, query, getDocFromServer, enableIndexedDbPersistence, where, onSnapshot, disableNetwork, enableNetwork } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Firebase Initialization
export const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true
}, firebaseConfig.firestoreDatabaseId);

// Enable persistence so offline mode works natively without sync queues!
if (typeof window !== 'undefined') {
  if (isQuotaPaused()) {
    disableNetwork(db).catch(() => {});
  }
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code == 'failed-precondition') {
      // Multiple tabs open
    } else if (err.code == 'unimplemented') {
      // Browser doesn't support
    }
  });
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

export function markQuotaExceeded() {
  try {
    localStorage.setItem('bizflow_quota_exhausted', String(Date.now() + 24 * 60 * 60 * 1000));
    disableNetwork(db).catch(() => {});
  } catch (e) {}
}

export function isQuotaPaused(): boolean {
  try {
    const val = localStorage.getItem('bizflow_quota_exhausted');
    if (!val) return false;
    const expiry = Number(val);
    if (Date.now() > expiry) {
      localStorage.removeItem('bizflow_quota_exhausted');
      enableNetwork(db).catch(() => {});
      return false;
    }
    return true;
  } catch (e) {
    return false;
  }
}

export async function safeSetDoc(docRef: any, data: any, options?: any) {
  if (isQuotaPaused()) {
    return; // Data is preserved in local storage
  }
  try {
    await setDoc(docRef, data, options);
  } catch (err: any) {
    const errMsg = err instanceof Error ? err.message : String(err);
    if (errMsg.includes('resource-exhausted') || errMsg.includes('quota') || errMsg.includes('Quota limit exceeded')) {
      markQuotaExceeded();
      console.warn('Firestore write quota limit reached. Using local storage fallback.');
    } else {
      console.warn('Firestore setDoc notice:', errMsg);
    }
  }
}

export async function safeDeleteDoc(docRef: any) {
  if (isQuotaPaused()) return;
  try {
    await deleteDoc(docRef);
  } catch (err: any) {
    const errMsg = err instanceof Error ? err.message : String(err);
    if (errMsg.includes('resource-exhausted') || errMsg.includes('quota') || errMsg.includes('Quota limit exceeded')) {
      markQuotaExceeded();
      console.warn('Firestore delete quota limit reached. Handled locally.');
    }
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  if (errMsg.includes('resource-exhausted') || errMsg.includes('quota') || errMsg.includes('Quota limit exceeded')) {
    markQuotaExceeded();
    return;
  }
  console.warn(`Firestore Notice (${operationType} on ${path}):`, errMsg);

  if (
    errMsg.includes("offline") || 
    errMsg.includes("permission-denied")
  ) {
    return;
  }
}

import { getActiveOrgId } from './store';

export interface SyncPayload {
  id: string;
  table: string;
  action: 'insert' | 'update' | 'delete';
  data: any;
  timestamp: number;
  transactionId?: string;
}

const syncChannel = typeof window !== 'undefined' && typeof BroadcastChannel !== 'undefined' 
  ? new BroadcastChannel('bizflow_realtime_sync_channel_v1') 
  : null;

if (syncChannel) {
  syncChannel.onmessage = (event) => {
    if (event.data && event.data.table && event.data.data) {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: event.data }));
      }
    }
  };
}

export const broadcastSync = (table: string, data: any) => {
  if (syncChannel) {
    try {
      syncChannel.postMessage({ table, data });
    } catch (e) {}
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table, data } }));
  }
};

const PENDING_QUEUE_KEY = 'bizflow_pending_sync_queue_v1';
const PROCESSED_TX_KEY = 'bizflow_processed_tx_ids_v1';

export const getProcessedTxIds = (): string[] => {
  try {
    const raw = localStorage.getItem(PROCESSED_TX_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const markTxProcessed = (txId: string) => {
  if (!txId) return;
  try {
    const txSet = new Set(getProcessedTxIds());
    txSet.add(txId);
    const arr = Array.from(txSet).slice(-1000);
    localStorage.setItem(PROCESSED_TX_KEY, JSON.stringify(arr));
  } catch {}
};

export const isTxProcessed = (txId: string): boolean => {
  if (!txId) return false;
  try {
    const txSet = new Set(getProcessedTxIds());
    return txSet.has(txId);
  } catch {
    return false;
  }
};

export const deduplicateQueue = (queue: SyncPayload[]): SyncPayload[] => {
  if (!Array.isArray(queue)) return [];
  const map = new Map<string, SyncPayload>();
  for (const item of queue) {
    if (!item) continue;
    const txId = item.transactionId || item.data?.transactionId || item.data?.txId || `${item.table}_${item.id}_${item.action}`;
    const existing = map.get(txId);
    if (!existing || (item.timestamp || 0) >= (existing.timestamp || 0)) {
      map.set(txId, item);
    }
  }
  return Array.from(map.values());
};

export const getSyncQueue = (): SyncPayload[] => {
  try {
    const raw = localStorage.getItem(PENDING_QUEUE_KEY);
    const queue: SyncPayload[] = raw ? JSON.parse(raw) : [];
    return deduplicateQueue(queue);
  } catch {
    return [];
  }
};

export const saveSyncQueue = (queue: SyncPayload[]) => {
  try {
    const deduped = deduplicateQueue(queue);
    localStorage.setItem(PENDING_QUEUE_KEY, JSON.stringify(deduped));
  } catch {}
};

export const addToSyncQueue = async (payload: Omit<SyncPayload, 'id' | 'timestamp'> & { transactionId?: string }) => {
  const idStr = String(payload.data?.id || payload.data?.docId || Math.random().toString(36).substring(2, 10));
  const orgId = getActiveOrgId();
  const txId = payload.transactionId || payload.data?.transactionId || payload.data?.txId || `${payload.table}_${idStr}_${payload.action}`;

  // If already processed recently in cloud, skip duplicate insertion
  if (isTxProcessed(txId)) {
    console.log(`Transaction ${txId} already processed. Skipping duplicate sync addition.`);
    return;
  }

  const fullPayload: SyncPayload = {
    id: idStr,
    table: payload.table,
    action: payload.action,
    data: { ...payload.data, transactionId: txId },
    timestamp: Date.now(),
    transactionId: txId
  };

  if (isQuotaPaused()) {
    markTxProcessed(txId);
    const itemData = { ...payload.data, transactionId: txId, organizationId: orgId, updatedAt: Date.now() };
    if (payload.action === 'insert' && !itemData.id) {
      itemData.id = idStr;
    }
    broadcastSync(payload.table, itemData);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: payload.table, data: itemData } }));
    }
    return;
  }

  try {
     let ref = doc(db, payload.table, idStr);
     if (payload.action === 'insert' || payload.action === 'update') {
        const cleanData = (obj: any): any => {
          if (!obj || typeof obj !== 'object') return obj;
          const newObj: any = Array.isArray(obj) ? [] : {};
          Object.keys(obj).forEach(key => {
            const val = obj[key];
            if (val !== undefined) {
              newObj[key] = (val && typeof val === 'object') ? cleanData(val) : val;
            }
          });
          return newObj;
        };
        const itemData = cleanData({ ...payload.data, transactionId: txId, organizationId: orgId, updatedAt: Date.now() });
        if (payload.action === 'insert') {
           itemData.id = idStr;
        }
        await setDoc(ref, itemData, { merge: true });
        markTxProcessed(txId);
        broadcastSync(payload.table, itemData);
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: payload.table, data: itemData } }));
        }
        // Also ensure any pending items in queue are flushed
        if (typeof window !== 'undefined' && navigator.onLine) {
          setTimeout(() => processSyncQueue(), 500);
        }
        return;
     } else if (payload.action === 'delete') {
        await deleteDoc(ref).catch(() => {});
        if (payload.data?.docId && String(payload.data.docId) !== idStr) {
          await deleteDoc(doc(db, payload.table, String(payload.data.docId))).catch(() => {});
        }
        markTxProcessed(txId);
        return;
     }
  } catch (error: any) {
     const errMsg = error instanceof Error ? error.message : String(error);
     if (errMsg.includes('resource-exhausted') || errMsg.includes('quota') || errMsg.includes('Quota limit exceeded')) {
       markQuotaExceeded();
     }
     console.warn(`Firestore sync write failed for ${payload.table}, queuing for background sync:`, errMsg);
     
     // Store in pending queue for background retry
     const currentQueue = getSyncQueue();
     const filtered = currentQueue.filter(q => {
       const qTxId = q.transactionId || q.data?.transactionId || q.data?.txId || `${q.table}_${q.id}_${q.action}`;
       return !(q.table === payload.table && (q.id === idStr || qTxId === txId));
     });
     filtered.push(fullPayload);
     saveSyncQueue(filtered);
  }
};

export const processSyncQueue = async () => {
  if (typeof window === 'undefined' || !navigator.onLine) return;
  if (isQuotaPaused()) {
    return;
  }
  const queue = getSyncQueue();
  if (queue.length === 0) return;

  const remaining: SyncPayload[] = [];
  let quotaExceeded = false;
  const processedInRun = new Set<string>();

  for (const item of queue) {
    const txId = item.transactionId || item.data?.transactionId || item.data?.txId || `${item.table}_${item.id}_${item.action}`;
    
    // Skip duplicate transaction without re-adding to remaining if processed
    if (isTxProcessed(txId) || processedInRun.has(txId)) {
      continue;
    }

    if (quotaExceeded || isQuotaPaused()) {
      remaining.push(item);
      continue;
    }
    const orgId = getActiveOrgId();
    try {
      const ref = doc(db, item.table, item.id);
      if (item.action === 'delete') {
        await deleteDoc(ref).catch(() => {});
        if (item.data?.docId && String(item.data.docId) !== item.id) {
          await deleteDoc(doc(db, item.table, String(item.data.docId))).catch(() => {});
        }
        markTxProcessed(txId);
        processedInRun.add(txId);
      } else {
        const cleanData = (obj: any): any => {
          if (!obj || typeof obj !== 'object') return obj;
          const newObj: any = Array.isArray(obj) ? [] : {};
          Object.keys(obj).forEach(key => {
            const val = obj[key];
            if (val !== undefined) {
              newObj[key] = (val && typeof val === 'object') ? cleanData(val) : val;
            }
          });
          return newObj;
        };
        const itemData = cleanData({ ...item.data, transactionId: txId, organizationId: orgId, updatedAt: Date.now() });
        await setDoc(ref, itemData, { merge: true });
        markTxProcessed(txId);
        processedInRun.add(txId);
        broadcastSync(item.table, itemData);
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: item.table, data: itemData } }));
        }
      }
    } catch (err: any) {
      const errMsg = err instanceof Error ? err.message : String(err);
      if (errMsg.includes('resource-exhausted') || errMsg.includes('quota') || errMsg.includes('Quota limit exceeded')) {
        quotaExceeded = true;
        markQuotaExceeded();
        console.warn('Firestore daily write quota reached. Pausing background sync queue until reset.');
      }
      remaining.push(item);
    }
  }

  saveSyncQueue(remaining);
};

export const fetchTableData = async (table: string) => {
  const orgId = getActiveOrgId();
  const localKey = `bizflow_${orgId}_${table}_v1`;
  const fallbackKey = `bizflow_${table}_v1`;
  const localStr = localStorage.getItem(localKey) || localStorage.getItem(fallbackKey);
  let localDocs: any[] = [];
  try {
    if (localStr) localDocs = JSON.parse(localStr);
  } catch (e) {}

  if (isQuotaPaused()) {
    return localDocs;
  }

  try {
    const q = query(collection(db, table));
    const snapshot = await getDocs(q);
    const cloudDocs = snapshot.docs
      .map(d => {
        const data = d.data();
        return { ...data, id: data.id || d.id, docId: d.id };
      })
      .filter((item: any) => !item.organizationId || item.organizationId === orgId);

    const syncQueue = typeof getSyncQueue === 'function' ? getSyncQueue() : [];
    const deletedIds = new Set(
      syncQueue
        .filter(q => q.table === table && q.action === 'delete')
        .map(q => String(q.id))
    );

    const getEpoch = (s: any) => {
      if (!s) return 0;
      if (s.updatedAt) return Number(s.updatedAt);
      if (s.createdAt) return new Date(s.createdAt).getTime();
      if (s.date) return new Date(s.date).getTime();
      if (s.timestamp) return Number(s.timestamp);
      return 0;
    };

    const mergedMap = new Map<string, any>();
    const seenTxIds = new Map<string, string>(); // txId -> id

    const processItem = (item: any) => {
      if (!item || item.id === undefined || item.id === null) return;
      const idStr = String(item.id);
      const docIdStr = item.docId ? String(item.docId) : idStr;
      if (deletedIds.has(idStr) || deletedIds.has(docIdStr)) return;

      const txId = item.transactionId || item.txId;
      if (txId) {
        const existingId = seenTxIds.get(String(txId));
        if (existingId && existingId !== idStr) {
          const existingItem = mergedMap.get(existingId);
          const existingTime = getEpoch(existingItem);
          const currentTime = getEpoch(item);
          if (currentTime <= existingTime) {
            return;
          } else {
            mergedMap.delete(existingId);
          }
        }
        seenTxIds.set(String(txId), idStr);
      }

      if (!mergedMap.has(idStr)) {
        mergedMap.set(idStr, item);
      } else {
        const existingItem = mergedMap.get(idStr);
        if (getEpoch(item) >= getEpoch(existingItem)) {
          mergedMap.set(idStr, item);
        }
      }
    };

    cloudDocs.forEach(processItem);

    if (Array.isArray(localDocs)) {
      localDocs.forEach(processItem);
    }

    const finalDocs = Array.from(mergedMap.values()).sort((a, b) => getEpoch(b) - getEpoch(a));

    if (finalDocs.length > 0) {
      localStorage.setItem(localKey, JSON.stringify(finalDocs));
      localStorage.setItem(fallbackKey, JSON.stringify(finalDocs));
    }

    return finalDocs;
  } catch (error) {
    const localKey = `bizflow_${orgId}_${table}_v1`;
    const fallbackKey = `bizflow_${table}_v1`;
    const localStr = localStorage.getItem(localKey) || localStorage.getItem(fallbackKey);
    if (localStr) {
      try { return JSON.parse(localStr); } catch (e) {}
    }
    if (String(error).includes('offline')) return [];
    handleFirestoreError(error, OperationType.GET, table);
    return null;
  }
};

export const fetchAllOrganizations = async () => {
  try {
    const q = query(collection(db, 'organizations'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data());
  } catch (error) {
    console.error('Failed to fetch organizations', error);
    return [];
  }
};

export const saveOrganization = async (org: any) => {
  try {
    await safeSetDoc(doc(db, 'organizations', org.id), org, { merge: true });
  } catch (error) {
    console.warn('Failed to save organization to cloud', error);
  }
};

export const deleteOrganization = async (orgId: string) => {
  try {
    await deleteDoc(doc(db, 'organizations', orgId));
  } catch (error) {
    console.error('Failed to delete organization', error);
  }
};

export const checkSupabaseConnection = async (): Promise<{ success: boolean; message: string }> => {
  try {
    // Check firebase connection - use a more robust way that doesn't just hang or throw aggressively
    const connRef = doc(db, 'system', 'connection_test');
    // Using getDoc with server source but with a timeout effectively
    const testDoc = await Promise.race([
      getDocFromServer(connRef),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 5000))
    ]);
    return { success: true, message: 'Connected to Firebase. Set to Spark Plan (Free Tier).' };
  } catch (error: any) {
    console.warn('Firebase check failed:', error.message);
    if(error.message === 'timeout') {
      return { success: false, message: 'Connection timed out. Working in offline mode.' };
    }
    if(error instanceof Error && (error.message.includes('the client is offline') || error.message.includes('unavailable'))) {
      return { success: false, message: 'Device is offline or Firebase is unreachable. Data saves locally.' };
    }
    return { success: false, message: 'Could not reach Firebase.' };
  }
};

export const pushUnsyncedLocalDataToCloud = async () => {
  if (typeof window === 'undefined' || !navigator.onLine || isQuotaPaused()) return;
  const orgId = getActiveOrgId();

  // 1. Flush any pending items in sync queue first
  await processSyncQueue();

  const collectionsToSync = ['sales', 'settlements', 'expenses', 'customers', 'suppliers', 'main_return_stock'];

  for (const table of collectionsToSync) {
    try {
      // Get cloud records
      const q = query(collection(db, table));
      const snapshot = await getDocs(q);
      const cloudMap = new Map<string, any>();
      const cloudTxSet = new Set<string>();

      snapshot.docs.forEach(d => {
        const data = d.data();
        const docId = String(d.id);
        const itemId = String(data.id || docId);
        cloudMap.set(docId, data);
        cloudMap.set(itemId, data);
        if (data.transactionId) cloudTxSet.add(String(data.transactionId));
        if (data.txId) cloudTxSet.add(String(data.txId));
      });

      // Get local records
      const localKey = `bizflow_${orgId}_${table}_v1`;
      const fallbackKey = `bizflow_${table}_v1`;
      const localStr = localStorage.getItem(localKey) || localStorage.getItem(fallbackKey);
      if (!localStr) continue;

      let localDocs: any[] = [];
      try {
        localDocs = JSON.parse(localStr);
      } catch (e) {
        continue;
      }

      if (!Array.isArray(localDocs)) continue;

      // Identify local docs missing in Cloud or updated locally
      for (const item of localDocs) {
        if (!item || item.id === undefined || item.id === null) continue;
        const itemId = String(item.id);
        const txId = String(item.transactionId || item.txId || `${table}_${itemId}_sync`);

        const cloudDoc = cloudMap.get(itemId);
        const existsInCloud = !!cloudDoc || cloudTxSet.has(txId);

        let needsPush = !existsInCloud;
        if (existsInCloud && cloudDoc) {
          const cloudTime = cloudDoc.updatedAt || new Date(cloudDoc.createdAt || cloudDoc.date || 0).getTime();
          const localTime = item.updatedAt || new Date(item.createdAt || item.date || 0).getTime();
          if (localTime > cloudTime + 1000) {
            needsPush = true;
          }
        }

        if (needsPush) {
          const cleanData = (obj: any): any => {
            if (!obj || typeof obj !== 'object') return obj;
            const newObj: any = Array.isArray(obj) ? [] : {};
            Object.keys(obj).forEach(key => {
              const val = obj[key];
              if (val !== undefined) {
                newObj[key] = (val && typeof val === 'object') ? cleanData(val) : val;
              }
            });
            return newObj;
          };
          const itemData = cleanData({ ...item, transactionId: txId, organizationId: orgId, updatedAt: item.updatedAt || Date.now() });
          await setDoc(doc(db, table, itemId), itemData, { merge: true });
          markTxProcessed(txId);
        }
      }
    } catch (err) {
      console.warn(`Local cloud push notice for ${table}:`, err);
    }
  }

  // Note: system docs (Admin inventory, returns, aiactions, repinv) are saved directly on user modification
  // to avoid wasteful background write loops.
};

let listenersInitialized = false;

export const initRealtimeSyncListeners = () => {
  if (typeof window === 'undefined' || listenersInitialized || isQuotaPaused()) return;
  listenersInitialized = true;

  const orgId = getActiveOrgId();
  const tables = ['sales', 'settlements', 'expenses', 'customers', 'suppliers', 'main_return_stock'];

  tables.forEach(table => {
    try {
      const colRef = collection(db, table);
      onSnapshot(colRef, (snapshot) => {
        if (snapshot.metadata.hasPendingWrites) return;
        const cloudDocs = snapshot.docs.map(d => {
          const data = d.data();
          return { ...data, id: data.id || d.id, docId: d.id };
        }).filter((item: any) => !item.organizationId || item.organizationId === orgId);

        if (cloudDocs.length === 0) return;

        const localKey = `bizflow_${orgId}_${table}_v1`;
        const fallbackKey = `bizflow_${table}_v1`;
        const localStr = localStorage.getItem(localKey) || localStorage.getItem(fallbackKey);
        let localDocs: any[] = [];
        try {
          if (localStr) localDocs = JSON.parse(localStr);
        } catch (e) {}

        const mergedMap = new Map<string, any>();
        localDocs.forEach(item => {
          if (item && item.id !== undefined) mergedMap.set(String(item.id), item);
        });
        cloudDocs.forEach((item: any) => {
          if (item && item.id !== undefined) {
            const existing = mergedMap.get(String(item.id));
            const cTime = item.updatedAt || Number(item.createdAt) || 0;
            const eTime = existing ? (existing.updatedAt || Number(existing.createdAt) || 0) : 0;
            if (!existing || cTime >= eTime) {
              mergedMap.set(String(item.id), item);
            }
          }
        });

        const finalDocs = Array.from(mergedMap.values());
        localStorage.setItem(localKey, JSON.stringify(finalDocs));
        localStorage.setItem(fallbackKey, JSON.stringify(finalDocs));

        broadcastSync(table, finalDocs);
      }, (error) => {
        const errMsg = error?.message || String(error);
        if (errMsg.includes('quota') || errMsg.includes('resource-exhausted')) {
          markQuotaExceeded();
        }
      });
    } catch (e) {}
  });

  try {
    const sysCol = collection(db, 'system');
    onSnapshot(sysCol, (snapshot) => {
      if (snapshot.metadata.hasPendingWrites) return;
      snapshot.docChanges().forEach(change => {
        if (change.type === 'added' || change.type === 'modified') {
          const docData = change.doc.data();
          const docId = change.doc.id;
          if (docId.startsWith(`org_${orgId}_`)) {
            if (docId.includes('_inventory')) {
              localStorage.setItem(`bizflow_${orgId}_admin_inventory_v1`, JSON.stringify(docData.data));
              localStorage.setItem('bizflow_admin_inventory_v1', JSON.stringify(docData.data));
              broadcastSync('admin_inventory', docData.data);
            } else if (docId.includes('_returns')) {
              localStorage.setItem(`bizflow_${orgId}_main_return_stock_v1`, JSON.stringify(docData.data));
              localStorage.setItem('bizflow_main_return_stock_v1', JSON.stringify(docData.data));
              broadcastSync('main_return_stock', docData.data);
            } else if (docId.includes('_repinv_')) {
              const repId = docId.replace(`org_${orgId}_repinv_`, '');
              localStorage.setItem(`bizflow_${orgId}_repinv_${repId}`, JSON.stringify(docData.data));
              broadcastSync(`repinv_${repId}`, docData.data);
            } else if (docId.includes('_settings')) {
              localStorage.setItem(`bizflow_${orgId}_settings`, JSON.stringify(docData));
              broadcastSync('settings', docData);
            }
          }
        }
      });
    }, (error) => {
      const errMsg = error?.message || String(error);
      if (errMsg.includes('quota') || errMsg.includes('resource-exhausted')) {
        markQuotaExceeded();
      }
    });
  } catch (e) {}
};
