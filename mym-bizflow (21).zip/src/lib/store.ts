export function getActiveOrgId(): string {
  return 'MYM-BIZFLOW';
};

export function setActiveOrgId(_id: string) {
  // No longer needed for single organization app
};

export interface OrganizationSettings {
  id: string;
  name: string;
  address?: string;
  phone?: string;
  email?: string;
  printerSize?: '58'|'80';
  printerFontSize?: number;
  printerFontWeight?: number;
  logoUrl?: string;
  hasStockKeeper?: boolean;
  hasStaff?: boolean;
  hasAI?: boolean;
  createdAt?: number;
  isLocked?: boolean;
}

export const getOrganizationSettings = (): OrganizationSettings => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_settings`);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Ensure createdAt exists for old orgs (mocking 3 months ago if missing so feature works for current users if they want)
      if (!parsed.createdAt) {
          parsed.createdAt = Date.now() - (90 * 24 * 60 * 60 * 1000); 
          localStorage.setItem(`bizflow_${orgId}_settings`, JSON.stringify(parsed));
      }
      return parsed;
    }
  } catch (e) {}
  return { id: orgId, name: 'MYM BIZFLOW', printerSize: '58', printerFontSize: 13, printerFontWeight: 700, createdAt: Date.now() };
};

export const saveOrganizationSettings = (settings: OrganizationSettings) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_settings`, JSON.stringify(settings));
  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_settings`), { 
      ...settings,
      updatedAt: Date.now()
    }, { merge: true });
  });
};

export interface SystemUser {
  id: string;
  name: string;
  pin: string;
  email?: string;
  role: 'admin' | 'rep' | 'super_admin' | 'stock_keeper' | 'driver' | 'other';
  organizationId: string;
  advances?: number;
  cashBookBalance?: number;
  pendingAdminHandover?: number;
  salaryBalance?: number;
  baseSalary?: number;
  attendanceAllowance?: number;
  hourlyRate?: number;
  otRate?: number;
  dailyWage?: number;
  payModel?: 'monthly' | 'daily' | 'hourly';
  customRoleName?: string;
  subscriptionPlan?: 'offline-only' | 'pro';
  subscriptionStart?: number;
  activeArea?: string;
  assignedPartnerId?: string;
  assignedVehicle?: string;
  lockedFeatures?: string[];
  lastOnline?: number;
}

export const getUsers = (): SystemUser[] => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_users_v2`);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {}
  
  // Default Admin User for this org
  const defaults: SystemUser[] = [{ 
    id: `admin_${orgId}`, 
    name: 'Admin', 
    pin: '1993', 
    role: 'admin',
    organizationId: orgId 
  }];
  localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(defaults));
  return defaults;
};


export const deleteSystemUser = (userId: string) => {
  const orgId = getActiveOrgId();
  const currentUsers = getUsers().filter(u => u.id !== userId);
  localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(currentUsers));
  
  Promise.all([import('firebase/firestore'), import('./sync')]).then(async ([ {doc}, {db, safeSetDoc, safeDeleteDoc} ]) => {
    const sanitize = (obj: any): any => JSON.parse(JSON.stringify(obj));
    // 1. Update legacy single-doc
    safeSetDoc(doc(db, 'system', `org_${orgId}_users`), { 
      data: sanitize(currentUsers),
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });

    // 2. Delete individual user doc
    safeDeleteDoc(doc(db, 'users', userId));
    safeDeleteDoc(doc(db, 'system', `org_${orgId}_repinv_${userId}`));
  });
};

export const saveUsers = (users: SystemUser[]) => {
  const orgId = getActiveOrgId();
  const cleanUsers = users;
  localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(cleanUsers));
  
  // Also push to standard 'users' collection for multi-device reliability
  Promise.all([import('firebase/firestore'), import('./sync')]).then(async ([ {doc}, {db, safeSetDoc} ]) => {
    const sanitize = (obj: any): any => JSON.parse(JSON.stringify(obj));
    // 1. Legacy single-doc sync for backward compatibility with current syncAllFromCloud
    safeSetDoc(doc(db, 'system', `org_${orgId}_users`), { 
      data: sanitize(cleanUsers),
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });

    // 2. Individual user doc sync for better multi-user reliability
    for (const user of cleanUsers) {
      safeSetDoc(doc(db, 'users', user.id), {
        ...sanitize(user),
        organizationId: orgId,
        updatedAt: Date.now()
      }, { merge: true });
    }
  });
};

export const updateUserOnlineStatus = (userId: string) => {
  if (!userId) return;
  const users = getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx >= 0) {
    const now = Date.now();
    const last = users[idx].lastOnline || 0;
    // Always update local storage for fast UI feedback
    users[idx].lastOnline = now;
    const orgId = getActiveOrgId();
    localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(users));

    // Throttle cloud write to once every 15 minutes to preserve Firestore quota
    if (!last || now - last > 15 * 60 * 1000) {
      saveUsers(users);
    }
  }
};

export const formatLastOnline = (timestamp?: number, lang: 'en' | 'si' = 'en') => {
  if (!timestamp) {
    return {
      text: lang === 'si' ? 'තවම ඔන්ලයින් වී නැත' : 'Never Online',
      isOnline: false,
      badgeColor: 'bg-slate-100 text-slate-500 border-slate-200'
    };
  }

  const diffMs = Date.now() - timestamp;
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);

  if (diffMins < 2) {
    return {
      text: lang === 'si' ? 'දැන් ඔන්ලයින්' : 'Online Now',
      isOnline: true,
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-300 font-bold'
    };
  }

  if (diffMins < 60) {
    return {
      text: lang === 'si' ? `මීට මිනිත්තු ${diffMins} කට පෙර` : `${diffMins}m ago`,
      isOnline: false,
      badgeColor: 'bg-amber-50 text-amber-800 border-amber-200'
    };
  }

  const dateObj = new Date(timestamp);
  const todayStr = new Date().toLocaleDateString();
  const timeStr = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (dateObj.toLocaleDateString() === todayStr) {
    return {
      text: lang === 'si' ? `අද ${timeStr}` : `Today at ${timeStr}`,
      isOnline: false,
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200'
    };
  }

  const dateStr = dateObj.toLocaleDateString();
  return {
    text: `${dateStr} ${timeStr}`,
    isOnline: false,
    badgeColor: 'bg-slate-100 text-slate-700 border-slate-200'
  };
};

export interface RepInventoryItem {
  id: number;
  name: string;
  minPrice: number;
  maxPrice: number;
  stockInMain: number;
  myStock: number;
  returnStock: number;
  costPrice: number;
  area?: string;
}

export const getRepInventory = (repId: string): RepInventoryItem[] => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_repinv_${repId}`);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch(e) {}
  return [];
};

export const saveRepInventory = (repId: string, inv: RepInventoryItem[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_repinv_${repId}`, JSON.stringify(inv));
  
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: `repinv_${repId}`, data: inv } }));
  }

  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc, broadcastSync} ]) => {
    const sanitize = (obj: any): any => JSON.parse(JSON.stringify(obj));
    if (broadcastSync) broadcastSync(`repinv_${repId}`, sanitize(inv));
    safeSetDoc(doc(db, 'system', `org_${orgId}_repinv_${repId}`), { 
      data: sanitize(inv),
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
  });
};

export interface AttendanceRecord {
  id: string;
  repId: string;
  repName: string;
  date: string;
  timestamp: number;
  status: 'Pending' | 'Approved' | 'Rejected';
  location?: string;
  dailySale?: number;
  dailyBonus?: number;
  workingHours?: number;
  otHours?: number;
  isEndDay?: boolean;
}

export const getAttendanceRecords = (): AttendanceRecord[] => {
  const orgId = getActiveOrgId();
  try {
    const stored1 = localStorage.getItem(`bizflow_${orgId}_attendance_v1`);
    const stored2 = localStorage.getItem(`bizflow_${orgId}_staff_attendance_v1`);
    const list1: AttendanceRecord[] = stored1 ? JSON.parse(stored1) : [];
    const list2: StaffAttendance[] = stored2 ? JSON.parse(stored2) : [];
    
    const map = new Map<string, AttendanceRecord>();
    list1.forEach(r => {
      const uId = r.repId || (r as any).userId;
      if (uId && r.date) {
        map.set(`${uId}_${r.date}`, r);
      }
    });

    list2.forEach(s => {
      if (s.userId && s.date) {
        const key = `${s.userId}_${s.date}`;
        if (!map.has(key)) {
          map.set(key, {
            id: s.id || 'att_' + Date.now(),
            repId: s.userId,
            repName: s.userName || 'Staff',
            date: s.date,
            timestamp: s.checkIn || Date.now(),
            status: 'Approved',
            workingHours: s.workingHours || 0,
            otHours: s.otHours || 0,
            isEndDay: !!s.checkOut
          });
        } else {
          const existing = map.get(key)!;
          if (s.workingHours && (!existing.workingHours || existing.workingHours === 0)) existing.workingHours = s.workingHours;
          if (s.otHours && (!existing.otHours || existing.otHours === 0)) existing.otHours = s.otHours;
        }
      }
    });

    return Array.from(map.values());
  } catch (e) {}
  return [];
};

export const saveAttendanceRecords = (records: AttendanceRecord[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_attendance_v1`, JSON.stringify(records));
  
  const existingStaffStr = localStorage.getItem(`bizflow_${orgId}_staff_attendance_v1`);
  let staffList: StaffAttendance[] = existingStaffStr ? JSON.parse(existingStaffStr) : [];
  
  const staffMap = new Map<string, StaffAttendance>();
  staffList.forEach(s => staffMap.set(s.id, s));

  records.forEach(r => {
    staffMap.set(r.id, {
      id: r.id,
      userId: r.repId,
      userName: r.repName,
      date: r.date,
      checkIn: r.timestamp,
      checkOut: r.isEndDay ? r.timestamp + ((r.workingHours || 8) * 3600000) : undefined,
      workingHours: r.workingHours || 0,
      otHours: r.otHours || 0,
      organizationId: orgId
    });
  });
  
  const newStaffList = Array.from(staffMap.values());
  localStorage.setItem(`bizflow_${orgId}_staff_attendance_v1`, JSON.stringify(newStaffList));
  
  const staffListForCloud = newStaffList; // rename to match downstream usage

  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_attendance`), { 
      data: records,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
    safeSetDoc(doc(db, 'system', `org_${orgId}_staff_attendance`), { 
      data: staffListForCloud,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
  });

  window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: 'attendance' } }));
};

export interface SettlementRecord {
  id: string;
  repId: string;
  repName?: string;
  date: string;
  timestamp: number;
  totalCash?: number;
  totalCheque?: number;
  expensesDeduction?: number;
  advancesDeduction?: number;
  netCashHandedOver?: number;
  salesCount?: number;
  status: 'Settled';
  submittedOnline: boolean;
  organizationId: string;
}

export const getSettlementRecords = (): SettlementRecord[] => {
  const orgId = getActiveOrgId();
  try {
    const raw = localStorage.getItem(`bizflow_${orgId}_settlements_v1`);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const getSettledDates = (repId: string): string[] => {
  if (!repId) return [];
  const orgId = getActiveOrgId();
  try {
    const key = `bizflow_${orgId}_${repId}_settled_dates`;
    const raw = localStorage.getItem(key);
    const localDates: string[] = raw ? JSON.parse(raw) : [];

    const allRecords = getSettlementRecords();
    const globalDates = allRecords.filter(r => r.repId === repId).map(r => r.date);

    return Array.from(new Set([...localDates, ...globalDates]));
  } catch {
    return [];
  }
};

export const markDatesSettled = (repId: string, dates: string[], details?: { 
  totalCash?: number; 
  totalCheque?: number; 
  repName?: string;
  expensesDeduction?: number;
  advancesDeduction?: number;
  netCashHandedOver?: number;
  salesCount?: number;
}) => {
  if (!repId) return;
  const orgId = getActiveOrgId();
  const existingRecords = getSettlementRecords();
  const now = Date.now();
  
  const newRecords: SettlementRecord[] = dates.map(d => ({
    id: `SETTL-${repId}-${d}-${now}`,
    repId,
    repName: details?.repName,
    date: d,
    timestamp: now,
    totalCash: details?.totalCash || 0,
    totalCheque: details?.totalCheque || 0,
    expensesDeduction: details?.expensesDeduction || 0,
    advancesDeduction: details?.advancesDeduction || 0,
    netCashHandedOver: details?.netCashHandedOver !== undefined ? details.netCashHandedOver : (details?.totalCash || 0),
    salesCount: details?.salesCount || 0,
    status: 'Settled',
    submittedOnline: navigator.onLine,
    organizationId: orgId
  }));

  const updatedRecords = [...existingRecords];
  newRecords.forEach(nr => {
    const idx = updatedRecords.findIndex(r => r.repId === nr.repId && r.date === nr.date);
    if (idx >= 0) {
      updatedRecords[idx] = nr;
    } else {
      updatedRecords.push(nr);
    }
  });

  localStorage.setItem(`bizflow_${orgId}_settlements_v1`, JSON.stringify(updatedRecords));

  const key = `bizflow_${orgId}_${repId}_settled_dates`;
  let existingDates: string[] = [];
  try {
    const raw = localStorage.getItem(key);
    existingDates = raw ? JSON.parse(raw) : [];
  } catch {}
  const updatedDates = Array.from(new Set([...existingDates, ...dates]));
  localStorage.setItem(key, JSON.stringify(updatedDates));

  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc, addToSyncQueue} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_settlements`), { 
      data: updatedRecords,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });

    newRecords.forEach(nr => {
      addToSyncQueue({ table: 'settlements', action: 'insert', data: nr });
    });
  });

  window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: 'settlements', data: updatedRecords } }));
};

export interface StaffAttendance {
  id: string;
  userId: string;
  userName: string;
  date: string;
  checkIn?: number;
  checkOut?: number;
  workingHours?: number;
  otHours?: number;
  note?: string;
  organizationId: string;
}

export const getStaffAttendance = (): StaffAttendance[] => {
  const orgId = getActiveOrgId();
  try {
    const stored1 = localStorage.getItem(`bizflow_${orgId}_staff_attendance_v1`);
    const stored2 = localStorage.getItem(`bizflow_${orgId}_attendance_v1`);
    const list1: StaffAttendance[] = stored1 ? JSON.parse(stored1) : [];
    const list2: AttendanceRecord[] = stored2 ? JSON.parse(stored2) : [];
    
    const map = new Map<string, StaffAttendance>();
    list1.forEach(s => {
      if (s.userId && s.date) {
        map.set(`${s.userId}_${s.date}`, s);
      }
    });

    list2.forEach(r => {
      const uId = r.repId || (r as any).userId;
      if (uId && r.date) {
        const key = `${uId}_${r.date}`;
        const wHours = (r.workingHours && r.workingHours > 0) ? r.workingHours : 8;
        if (!map.has(key)) {
          map.set(key, {
            id: r.id || 'staff_att_' + Date.now(),
            userId: uId,
            userName: r.repName || 'Staff',
            date: r.date,
            checkIn: r.timestamp || Date.now(),
            checkOut: r.isEndDay ? (r.timestamp || Date.now()) + (wHours * 3600000) : (r.timestamp ? r.timestamp + (wHours * 3600000) : undefined),
            workingHours: wHours,
            otHours: r.otHours || 0,
            organizationId: orgId
          });
        } else {
          const existing = map.get(key)!;
          if (!existing.workingHours || existing.workingHours === 0) existing.workingHours = wHours;
          if (r.otHours && (!existing.otHours || existing.otHours === 0)) existing.otHours = r.otHours;
        }
      }
    });

    return Array.from(map.values());
  } catch (e) {}
  return [];
};

export const saveStaffAttendance = (records: StaffAttendance[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_staff_attendance_v1`, JSON.stringify(records));
  
  const attList: AttendanceRecord[] = records.map(s => ({
    id: s.id,
    repId: s.userId,
    repName: s.userName,
    date: s.date,
    timestamp: s.checkIn || Date.now(),
    status: 'Approved',
    workingHours: s.workingHours || 0,
    otHours: s.otHours || 0,
    isEndDay: !!s.checkOut
  }));
  localStorage.setItem(`bizflow_${orgId}_attendance_v1`, JSON.stringify(attList));

  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_staff_attendance`), { 
      data: records,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
    safeSetDoc(doc(db, 'system', `org_${orgId}_attendance`), { 
      data: attList,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
  });

  window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: 'attendance' } }));
};

export interface AIActionRequest {
  id: string;
  repId: string;
  repName?: string;
  type?: string;
  actionType?: 'add_expense' | 'add_bill' | 'update_stock' | 'delete_record' | 'product_add' | 'supplier_buy' | 'rep_load' | 'stock_load' | 'stock_load_rep' | 'stock_load_admin' | 'sale_cancel' | 'handover_admin' | 'price_approval' | 'rep_return_handover' | 'rep_good_stock_handover' | 'other';
  description?: string;
  payload?: any;
  metadata?: any;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Completed';
  timestamp: string | number;
  createdRole?: string;
}

export const getAIActionRequests = (): AIActionRequest[] => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_aiactions_v1`) || localStorage.getItem('bizflow_aiactions_v1');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
};

export const saveAIActionRequests = (requests: AIActionRequest[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_aiactions_v1`, JSON.stringify(requests));
  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_aiactions`), { 
      data: requests,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
  });
};

export const getAdminInventory = (): any[] => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_admin_inventory_v1`) || localStorage.getItem('bizflow_admin_inventory_v1');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
};

export const saveAdminInventory = (inventory: any[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_admin_inventory_v1`, JSON.stringify(inventory));
  localStorage.setItem(`bizflow_admin_inventory_v1`, JSON.stringify(inventory));
  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    safeSetDoc(doc(db, 'system', `org_${orgId}_inventory`), { 
      data: inventory,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
  });
};

export const getMainReturnStock = (): any[] => {
  const orgId = getActiveOrgId();
  try {
    const stored = localStorage.getItem(`bizflow_${orgId}_main_return_stock_v1`) || localStorage.getItem('bizflow_main_return_stock_v1');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
};

export const saveMainReturnStock = (stock: any[]) => {
  const orgId = getActiveOrgId();
  localStorage.setItem(`bizflow_${orgId}_main_return_stock_v1`, JSON.stringify(stock));
  localStorage.setItem(`bizflow_main_return_stock_v1`, JSON.stringify(stock));
  Promise.all([import('firebase/firestore'), import('./sync')]).then(([ {doc}, {db, safeSetDoc} ]) => {
    // Legacy sync
    safeSetDoc(doc(db, 'system', `org_${orgId}_returns`), { 
      data: stock,
      organizationId: orgId,
      updatedAt: Date.now()
    }, { merge: true });
    
    // Individual docs
    for (const item of stock) {
      safeSetDoc(doc(db, 'main_return_stock', item.id), {
        ...item,
        organizationId: orgId,
        updatedAt: Date.now()
      }, { merge: true });
    }
  });
};

export const syncRequestsFromCloud = async () => {
  const orgId = getActiveOrgId();
  try {
    const [{ db }, { doc, getDoc }] = await Promise.all([import('./sync'), import('firebase/firestore')]);
    const aiDoc = await getDoc(doc(db, 'system', `org_${orgId}_aiactions`));
    if (aiDoc.exists() && aiDoc.data().data) {
      localStorage.setItem(`bizflow_${orgId}_aiactions_v1`, JSON.stringify(aiDoc.data().data));
      return aiDoc.data().data;
    }
  } catch (e) {
    console.warn('Sync requests notice:', e);
  }
  return null;
};

export const syncAllFromCloud = async () => {
  const orgId = getActiveOrgId();
  try {
    const [{ db, pushUnsyncedLocalDataToCloud }, { doc, getDoc, collection, query, where, getDocs }] = await Promise.all([import('./sync'), import('firebase/firestore')]);
    
    // First: push any local offline records or delayed entries from localStorage up to Cloud
    await pushUnsyncedLocalDataToCloud();
    
    // Sync Users - Merge legacy and new
    const usersMap = new Map<string, any>();
    
    // 1. Fetch Legacy
    const legacyDoc = await getDoc(doc(db, 'system', `org_${orgId}_users`));
    if (legacyDoc.exists() && legacyDoc.data().data) {
      const legacyArr = legacyDoc.data().data;
      if (Array.isArray(legacyArr)) {
        legacyArr.forEach(u => { if (u && u.id) usersMap.set(u.id, u); });
      }
    }
    
    // 2. Fetch new individual docs
    const usersQ = query(collection(db, 'users'), where("organizationId", "==", orgId));
    const usersSnap = await getDocs(usersQ);
    usersSnap.forEach(d => {
      const u = d.data();
      if (u && u.id) usersMap.set(u.id, u);
    });

    const mergedUsers = Array.from(usersMap.values());
    if (mergedUsers.length > 0) {
      localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(mergedUsers));
    }

    // Sync Attendance
    const attendanceDoc = await getDoc(doc(db, 'system', `org_${orgId}_attendance`));
    if (attendanceDoc.exists() && attendanceDoc.data().data) {
      localStorage.setItem(`bizflow_${orgId}_attendance_v1`, JSON.stringify(attendanceDoc.data().data));
    }

    // Sync Action Requests
    await syncRequestsFromCloud();

    // Sync Organization Settings
    const settingsDoc = await getDoc(doc(db, 'system', `org_${orgId}_settings`));
    if (settingsDoc.exists()) {
      localStorage.setItem(`bizflow_${orgId}_settings`, JSON.stringify(settingsDoc.data()));
    }
    
    // Sync Admin Inventory
    const invDoc = await getDoc(doc(db, 'system', `org_${orgId}_inventory`));
    if (invDoc.exists() && invDoc.data().data) {
      localStorage.setItem(`bizflow_${orgId}_admin_inventory_v1`, JSON.stringify(invDoc.data().data));
      localStorage.setItem('bizflow_admin_inventory_v1', JSON.stringify(invDoc.data().data));
    }

    // Sync Main Return Stock
    const retDoc = await getDoc(doc(db, 'system', `org_${orgId}_returns`));
    if (retDoc.exists() && retDoc.data().data) {
      localStorage.setItem(`bizflow_${orgId}_main_return_stock_v1`, JSON.stringify(retDoc.data().data));
      localStorage.setItem('bizflow_main_return_stock_v1', JSON.stringify(retDoc.data().data));
    }

    // Sync Rep Inventories
    for (const u of mergedUsers) {
      if (u && u.id) {
        const repInvDoc = await getDoc(doc(db, 'system', `org_${orgId}_repinv_${u.id}`));
        if (repInvDoc.exists() && repInvDoc.data().data) {
          localStorage.setItem(`bizflow_${orgId}_repinv_${u.id}`, JSON.stringify(repInvDoc.data().data));
        }
      }
    }

    // Sync Sales, Settlements, Expenses, Customers, Suppliers from collection level
    const [{ fetchTableData }] = await Promise.all([import('./sync')]);
    await Promise.all([
      fetchTableData('sales'),
      fetchTableData('settlements'),
      fetchTableData('expenses'),
      fetchTableData('customers'),
      fetchTableData('suppliers'),
      fetchTableData('main_return_stock')
    ]);

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('bizflow_sync', { detail: { table: 'all' } }));
    }

    return true;
  } catch (e) {
    console.warn('Sync cloud notice:', e);
    return false;
  }
};

export const syncRepFromCloud = async (repId: string) => {
  const orgId = getActiveOrgId();
  try {
    const [{ db }, { doc, getDoc }] = await Promise.all([import('./sync'), import('firebase/firestore')]);
    const repInvDoc = await getDoc(doc(db, 'system', `org_${orgId}_repinv_${repId}`));
    if (repInvDoc.exists() && repInvDoc.data().data) {
      localStorage.setItem(`bizflow_${orgId}_repinv_${repId}`, JSON.stringify(repInvDoc.data().data));
    }
  } catch (e) {
    console.warn('Sync rep data notice:', e);
  }
};

export const listenToCloudChanges = async (callback: (table: string, data: any) => void) => {
  const orgId = getActiveOrgId();
  const [{ db, getSyncQueue, isQuotaPaused, markQuotaExceeded }, { doc, onSnapshot, collection, query, where }] = await Promise.all([import('./sync'), import('firebase/firestore')]);
  if (isQuotaPaused()) return () => {};
  
  const repInvUnsubs = new Map<string, () => void>();

  // Listen to common tables
  const unsubs = [
    onSnapshot(query(collection(db, 'users')), (snapshot) => {
      const dbUsers: any[] = [];
      snapshot.forEach(d => dbUsers.push({ ...d.data(), id: d.data().id || d.id, docId: d.id }));
      const filteredDbUsers = dbUsers.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      // Merge with existing local storage to prevent wiping out legacy un-migrated users
      const localUsersStr = localStorage.getItem(`bizflow_${orgId}_users_v2`);
      let localUsers: any[] = [];
      try { if (localUsersStr) localUsers = JSON.parse(localUsersStr); } catch(e) {}
      
      const mergedMap = new Map<string, any>();
      localUsers.forEach(u => { if (u && u.id) mergedMap.set(String(u.id), u); });
      
      // Handle explicit deletions from other devices
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          mergedMap.delete(String(change.doc.id));
        }
      });

      filteredDbUsers.forEach(u => { if (u && u.id) mergedMap.set(String(u.id), u); });
      
      const finalUsers = Array.from(mergedMap.values());
      localStorage.setItem(`bizflow_${orgId}_users_v2`, JSON.stringify(finalUsers));
      
      // Attach real-time cloud listeners for all reps' loaded stock / inventory
      finalUsers.forEach((u: any) => {
        if (u && u.id && !repInvUnsubs.has(u.id)) {
          const unsubRep = onSnapshot(doc(db, 'system', `org_${orgId}_repinv_${u.id}`), (snap) => {
            if (snap.exists() && snap.data().data) {
              const invData = snap.data().data;
              localStorage.setItem(`bizflow_${orgId}_repinv_${u.id}`, JSON.stringify(invData));
              callback(`repinv_${u.id}`, invData);
              callback('repinv', { repId: u.id, data: invData });
            }
          }, () => {});
          repInvUnsubs.set(u.id, unsubRep);
        }
      });

      callback('users', finalUsers);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for users. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'suppliers')), (snapshot) => {
      const dbSups: any[] = [];
      snapshot.forEach(d => dbSups.push({ ...d.data(), id: d.data().id || d.id, docId: d.id }));
      const filteredDbSups = dbSups.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      
      const localSupsStr = localStorage.getItem(`bizflow_${orgId}_suppliers_v1`) || localStorage.getItem('bizflow_suppliers_v1');
      let localSups: any[] = [];
      try { if (localSupsStr) localSups = JSON.parse(localSupsStr); } catch(e) {}
      
      const mergedMap = new Map<string, any>();
      localSups.forEach(s => { if (s && s.id) mergedMap.set(String(s.id), s); });
      
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          mergedMap.delete(String(change.doc.id));
        }
      });
      
      filteredDbSups.forEach(s => { if (s && s.id) mergedMap.set(String(s.id), s); });
      
      const finalSups = Array.from(mergedMap.values());
      localStorage.setItem(`bizflow_${orgId}_suppliers_v1`, JSON.stringify(finalSups));
      localStorage.setItem(`bizflow_suppliers_v1`, JSON.stringify(finalSups));
      callback('suppliers', finalSups);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for suppliers. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'sales')), (snapshot) => {
      const dbSales: any[] = [];
      snapshot.forEach(d => {
        const data = d.data();
        const id = data.id || d.id;
        dbSales.push({ ...data, id, docId: d.id });
      });
      const filteredDbSales = dbSales.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      
      const localSalesStr = localStorage.getItem(`bizflow_${orgId}_sales_v1`) || localStorage.getItem('bizflow_sales_v1');
      let localSales: any[] = [];
      try { if (localSalesStr) localSales = JSON.parse(localSalesStr); } catch(e) {}
      
      const syncQueue = typeof getSyncQueue === 'function' ? getSyncQueue() : [];
      const deletedIds = new Set(
        syncQueue
          .filter(q => q.table === 'sales' && q.action === 'delete')
          .map(q => String(q.id))
      );

      const mergedMap = new Map<string, any>();
      
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          mergedMap.delete(String(change.doc.id));
        }
      });

      const getEpoch = (s: any) => {
        if (!s) return 0;
        if (s.updatedAt) return Number(s.updatedAt);
        if (s.createdAt) return new Date(s.createdAt).getTime();
        if (s.date) return new Date(s.date).getTime();
        if (s.timestamp) return Number(s.timestamp);
        return 0;
      };

      const processItem = (s: any) => {
        if (!s || !s.id) return;
        const sId = String(s.id);
        const sDocId = s.docId ? String(s.docId) : sId;
        if (deletedIds.has(sId) || deletedIds.has(sDocId)) return;

        if (!mergedMap.has(sId)) {
          mergedMap.set(sId, s);
        } else {
          const existing = mergedMap.get(sId);
          if (getEpoch(s) >= getEpoch(existing)) {
            mergedMap.set(sId, s);
          }
        }
      };

      filteredDbSales.forEach(processItem);
      localSales.forEach(processItem);
      
      const finalSales = Array.from(mergedMap.values()).sort((a, b) => getEpoch(b) - getEpoch(a));
      localStorage.setItem(`bizflow_${orgId}_sales_v1`, JSON.stringify(finalSales));
      localStorage.setItem(`bizflow_sales_v1`, JSON.stringify(finalSales));
      callback('sales', finalSales);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for sales. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'customers')), (snapshot) => {
      const dbCusts: any[] = [];
      snapshot.forEach(d => dbCusts.push(d.data()));
      const filteredDbCusts = dbCusts.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      
      const localCustsStr = localStorage.getItem(`bizflow_${orgId}_customers_v1`) || localStorage.getItem('bizflow_customers_v1');
      let localCusts: any[] = [];
      try { if (localCustsStr) localCusts = JSON.parse(localCustsStr); } catch(e) {}
      
      const mergedMap = new Map<string, any>();
      localCusts.forEach(c => { if (c && c.id) mergedMap.set(String(c.id), c); });
      
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          mergedMap.delete(String(change.doc.id));
        }
      });
      
      filteredDbCusts.forEach(c => { if (c && c.id) mergedMap.set(String(c.id), c); });
      
      const finalCusts = Array.from(mergedMap.values());
      localStorage.setItem(`bizflow_${orgId}_customers_v1`, JSON.stringify(finalCusts));
      localStorage.setItem(`bizflow_customers_v1`, JSON.stringify(finalCusts));
      callback('customers', finalCusts);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for customers. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'expenses')), (snapshot) => {
      const dbExp: any[] = [];
      snapshot.forEach(d => dbExp.push(d.data()));
      const filteredDbExp = dbExp.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      
      const localExpStr = localStorage.getItem(`bizflow_${orgId}_expenses_v1`) || localStorage.getItem('bizflow_expenses_v1');
      let localExp: any[] = [];
      try { if (localExpStr) localExp = JSON.parse(localExpStr); } catch(e) {}
      
      const mergedMap = new Map<string, any>();
      localExp.forEach(e => { if (e && e.id) mergedMap.set(String(e.id), e); });
      
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          mergedMap.delete(String(change.doc.id));
        }
      });
      
      filteredDbExp.forEach(e => { if (e && e.id) mergedMap.set(String(e.id), e); });
      
      const finalExp = Array.from(mergedMap.values());
      localStorage.setItem(`bizflow_${orgId}_expenses_v1`, JSON.stringify(finalExp));
      localStorage.setItem(`bizflow_expenses_v1`, JSON.stringify(finalExp));
      callback('expenses', finalExp);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for expenses. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'main_return_stock'), where('organizationId', '==', orgId)), (snapshot) => {
      const dbReturns: any[] = [];
      snapshot.forEach(d => dbReturns.push(d.data()));
      localStorage.setItem(`bizflow_${orgId}_main_return_stock_v1`, JSON.stringify(dbReturns));
      localStorage.setItem(`bizflow_main_return_stock_v1`, JSON.stringify(dbReturns));
      callback('main_return_stock', dbReturns);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for return stock. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(doc(db, 'system', `org_${orgId}_aiactions`), (snapshot) => {
      if (snapshot.exists() && snapshot.data().data) {
        localStorage.setItem(`bizflow_${orgId}_aiactions_v1`, JSON.stringify(snapshot.data().data));
        callback('aiactions', snapshot.data().data);
      }
    }, (error) => {
      console.warn("Real-time sync inactive or denied for actions. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(doc(db, 'system', `org_${orgId}_attendance`), (snapshot) => {
      if (snapshot.exists() && snapshot.data().data) {
        localStorage.setItem(`bizflow_${orgId}_attendance_v1`, JSON.stringify(snapshot.data().data));
        callback('attendance', snapshot.data().data);
      }
    }, (error) => {
      console.warn("Real-time sync inactive or denied for attendance. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(doc(db, 'system', `org_${orgId}_inventory`), (snapshot) => {
      if (snapshot.exists() && snapshot.data().data) {
        localStorage.setItem(`bizflow_${orgId}_admin_inventory_v1`, JSON.stringify(snapshot.data().data));
        localStorage.setItem(`bizflow_admin_inventory_v1`, JSON.stringify(snapshot.data().data));
        callback('inventory', snapshot.data().data);
      }
    }, (error) => {
      console.warn("Real-time sync inactive or denied for inventory. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(doc(db, 'system', `org_${orgId}_settings`), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        localStorage.setItem(`bizflow_${orgId}_settings`, JSON.stringify(data));
        callback('settings', data);
      }
    }, (error) => {
      console.warn("Real-time sync inactive or denied for settings. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(doc(db, 'system', `org_${orgId}_settlements`), (snapshot) => {
      if (snapshot.exists() && snapshot.data().data) {
        const data = snapshot.data().data;
        localStorage.setItem(`bizflow_${orgId}_settlements_v1`, JSON.stringify(data));
        callback('settlements', data);
      }
    }, (error) => {
      console.warn("Real-time sync inactive or denied for settlements. Operating on robust local cache fallback.", error);
    }),
    onSnapshot(query(collection(db, 'settlements')), (snapshot) => {
      const dbSettlements: any[] = [];
      snapshot.forEach(d => {
        const data = d.data();
        dbSettlements.push({ ...data, id: data.id || d.id, docId: d.id });
      });
      const filteredDbSettlements = dbSettlements.filter((item: any) => !item.organizationId || item.organizationId === orgId);
      
      const localSettlementsStr = localStorage.getItem(`bizflow_${orgId}_settlements_v1`);
      let localSettlements: any[] = [];
      try { if (localSettlementsStr) localSettlements = JSON.parse(localSettlementsStr); } catch(e) {}
      
      const mergedMap = new Map<string, any>();
      localSettlements.forEach(s => { if (s && s.id) mergedMap.set(String(s.id), s); });
      filteredDbSettlements.forEach(s => { if (s && s.id) mergedMap.set(String(s.id), s); });
      
      const finalSettlements = Array.from(mergedMap.values()).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      localStorage.setItem(`bizflow_${orgId}_settlements_v1`, JSON.stringify(finalSettlements));
      callback('settlements', finalSettlements);
    }, (error) => {
      console.warn("Real-time sync inactive or denied for settlements collection fallback.", error);
    })
  ];

  return () => {
    unsubs.forEach(unsub => unsub());
    repInvUnsubs.forEach(unsub => unsub());
  };
};

export const listenToRepInventory = async (repId: string, callback: (inv: RepInventoryItem[]) => void) => {
  const orgId = getActiveOrgId();
  const [{ db }, { doc, onSnapshot }] = await Promise.all([import('./sync'), import('firebase/firestore')]);
  return onSnapshot(doc(db, 'system', `org_${orgId}_repinv_${repId}`), (snapshot) => {
    if (snapshot.exists() && snapshot.data().data) {
      localStorage.setItem(`bizflow_${orgId}_repinv_${repId}`, JSON.stringify(snapshot.data().data));
      callback(snapshot.data().data);
    }
  }, (error) => {
    console.warn(`Real-time sync inactive or denied for rep inventory ${repId}. Operating on robust local cache fallback.`, error);
  });
};


