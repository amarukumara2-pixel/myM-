let cachedBluetoothDevice: any = null;
let cachedBluetoothCharacteristic: any = null;

export async function connectBluetoothPrinter(): Promise<boolean> {
  if (cachedBluetoothCharacteristic) return true;
  try {
    const device = await (navigator as any).bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [
        '000018f0-0000-1000-8000-00805f9b34fb', 
        'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
        '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        '0000fee7-0000-1000-8000-00805f9b34fb'
      ]
    });

    cachedBluetoothDevice = device;
    device.addEventListener('gattserverdisconnected', () => {
        cachedBluetoothDevice = null;
        cachedBluetoothCharacteristic = null;
    });

    const server = await device.gatt?.connect();
    if (!server) throw new Error("Could not connect to GATT server");

    let printCharacteristic: any = null;
    
    const services = await server.getPrimaryServices();
    for (const service of services) {
      const characteristics = await service.getCharacteristics();
      for (const char of characteristics) {
        if (char.properties.write || char.properties.writeWithoutResponse) {
          printCharacteristic = char;
          break;
        }
      }
      if (printCharacteristic) break;
    }

    if (!printCharacteristic) {
      throw new Error("Could not find a writable characteristic for this printer.");
    }
    cachedBluetoothCharacteristic = printCharacteristic;
    return true;
  } catch (error: any) {
    const msg = (error.message || '').toLowerCase();
    if (error.name === 'NotFoundError' || msg.includes('cancel') || msg.includes('chooser') || msg.includes('user denied')) {
      // User cancelled, don't show alert
      return false;
    }
    if (error.message.includes('Connection attempt failed') || error.message.includes('GATT operation failed')) {
      alert("Bluetooth Connection Failed: Please ensure the printer is turned on and nearby.");
      return false;
    }
    alert("Bluetooth Connection Failed: " + error.message);
    return false;
  }
}

export async function printCanvasViaBluetooth(canvas: HTMLCanvasElement, printerSize: '58' | '80' = '58'): Promise<boolean> {
  try {
    if (!cachedBluetoothCharacteristic) {
        console.warn("Bluetooth printer not connected. Cannot print without a user gesture to connect first.");
        return false;
    }

    const data = generateEscPosImage(canvas, printerSize);
    
    // Send in small chunks
    // Use 100 bytes to stay under common BLE MTU limits without exchange
    const chunkSize = 100;
    for (let i = 0; i < data.length; i += chunkSize) {
      const chunk = data.slice(i, i + chunkSize);
      
      let success = false;
      let retries = 3;
      while (!success && retries > 0) {
        try {
          if (cachedBluetoothCharacteristic.properties.writeWithoutResponse) {
            await cachedBluetoothCharacteristic.writeValueWithoutResponse(chunk);
          } else {
            await cachedBluetoothCharacteristic.writeValue(chunk);
          }
          success = true;
        } catch (e: any) {
          retries--;
          if (retries === 0) throw e;
          // Wait before retry
          await new Promise(r => setTimeout(r, 100));
        }
      }

      // Delay to avoid buffer overflow on portable thermal printers
      await new Promise(r => setTimeout(r, 40)); 
    }
    
    return true;
  } catch (error: any) {
    alert("Bluetooth Print Failed: " + error.message);
    cachedBluetoothCharacteristic = null;
    cachedBluetoothDevice?.gatt?.disconnect();
    return false;
  }
}

export function uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}

export function generateEscPosImage(canvas: HTMLCanvasElement, printerSize: '58' | '80' = '58'): Uint8Array {
    // 384 dots is the standard printable width for 58mm thermal printers
    const targetWidth = printerSize === '80' ? 576 : 384;
    const targetHeight = Math.floor(canvas.height * (targetWidth / canvas.width));
    
    const scaledCanvas = document.createElement('canvas');
    scaledCanvas.width = targetWidth;
    scaledCanvas.height = targetHeight;
    const scaledContext = scaledCanvas.getContext('2d', { willReadFrequently: true });
    if (!scaledContext) throw new Error("No 2d context");
    
    // White background to prevent transparent areas from turning black
    scaledContext.fillStyle = '#FFFFFF';
    scaledContext.fillRect(0, 0, targetWidth, targetHeight);
    
    // Draw and resize
    scaledContext.drawImage(canvas, 0, 0, targetWidth, targetHeight);
    
    const imageData = scaledContext.getImageData(0, 0, targetWidth, targetHeight);
    const data = imageData.data;
    
    const bytesWidth = Math.ceil(targetWidth / 8);
    const commands: number[] = [];
    
    // ESC @ : Initialize printer
    commands.push(0x1B, 0x40);
    // Align center
    commands.push(0x1B, 0x61, 0x01);

    const sliceHeight = 250;
    for (let currentY = 0; currentY < targetHeight; currentY += sliceHeight) {
        const currentSliceHeight = Math.min(sliceHeight, targetHeight - currentY);
        
        commands.push(0x1D, 0x76, 0x30, 0x00);
        commands.push(bytesWidth & 0xFF, (bytesWidth >> 8) & 0xFF);
        commands.push(currentSliceHeight & 0xFF, (currentSliceHeight >> 8) & 0xFF);
        
        for (let y = 0; y < currentSliceHeight; y++) {
            const absoluteY = currentY + y;
            for (let xByte = 0; xByte < bytesWidth; xByte++) {
                let byte = 0;
                for (let bit = 0; bit < 8; bit++) {
                    const x = xByte * 8 + bit;
                    if (x < targetWidth) {
                        const index = (absoluteY * targetWidth + x) * 4;
                        const r = data[index];
                        const g = data[index + 1];
                        const b = data[index + 2];
                        const brightness = (r * 0.299 + g * 0.587 + b * 0.114);
                        if (brightness < 160) {
                            byte |= (1 << (7 - bit));
                        }
                    }
                }
                commands.push(byte);
            }
        }
    }
    
    // Align left back
    commands.push(0x1B, 0x61, 0x00);
    // ESC d : Print and feed n lines (feed enough to clear tear bar)
    commands.push(0x1B, 0x64, 0x05); // Feed 5 lines to clear tear bar 
    // GS V : Partial cut (if the printer has an auto cutter)
    commands.push(0x1D, 0x56, 0x42, 0x00);
    
    return new Uint8Array(commands);
}
