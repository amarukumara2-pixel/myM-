import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Search, Calendar, UserX } from 'lucide-react';
import { fetchTableData } from '../lib/sync';
import { parseLocation } from '../lib/mapHelpers';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet's default icon path issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function MapLines({ groupedLocations }: { groupedLocations: Record<string, {lat: number, lng: number}[]> }) {
  const colors = ['#2563EB', '#D97706', '#059669', '#DC2626', '#7C3AED'];
  return (
    <>
      {Object.entries(groupedLocations).map(([repId, locations], idx) => {
        if (locations.length > 1) {
          return (
            <Polyline 
               key={repId} 
               positions={locations.map(loc => [loc.lat, loc.lng])} 
               color={colors[idx % colors.length]} 
               weight={4}
               opacity={0.8}
            />
          );
        }
        return null;
      })}
    </>
  );
}

// Custom hook to set map center and bounds
function MapUpdater({ mapLocations }: { mapLocations: {lat: number, lng: number}[] }) {
  const map = useMap();
  
  useEffect(() => {
    if (mapLocations.length > 0) {
      if (mapLocations.length === 1) {
        map.setView([mapLocations[0].lat, mapLocations[0].lng], 12);
      } else {
        const bounds = L.latLngBounds(mapLocations.map(loc => [loc.lat, loc.lng]));
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    } else {
      map.setView([7.8731, 80.7718], 7);
    }
  }, [mapLocations, map]);
  return null;
}

export default function RepRoutes() {
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchRep, setSearchRep] = useState('');
  const [searchDate, setSearchDate] = useState(() => new Date().toISOString().split('T')[0]);

  const [liveLocations, setLiveLocations] = useState<any[]>([]);

  useEffect(() => {
    loadSales();
    
    // Load live locations directly from Firestore
    let unsubLocs = () => {};
    Promise.all([import('firebase/firestore'), import('../lib/sync')]).then(([{ collection, query, where, onSnapshot }, { db, isQuotaPaused }]) => {
       if (isQuotaPaused()) return;
       const orgId = localStorage.getItem('bizflow_active_org') || 'MYM-BIZFLOW';
       unsubLocs = onSnapshot(query(collection(db, 'rep_locations'), where('organizationId', '==', orgId)), (snap) => {
           const locs: any[] = [];
           snap.forEach(doc => locs.push(doc.data()));
           setLiveLocations(locs);
       }, (err) => {
           console.warn('Rep locations sync notice:', err?.message || err);
       });
    });

    const handleSync = (e: any) => {
      if (e.detail?.table === 'sales') {
        loadSales();
      }
    };
    window.addEventListener('bizflow_sync', handleSync);
    return () => { window.removeEventListener('bizflow_sync', handleSync); unsubLocs(); };
  }, []);

  const loadSales = async () => {
    setLoading(true);
    const data = await fetchTableData('sales');
    if (data) {
      setSales((data as any[]).sort((a: any, b: any) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime()));
    }
    setLoading(false);
  };

  const filteredSales = sales.filter(s => {
      const matchRep = (s.repId || '').toLowerCase().includes((searchRep || '').toLowerCase()) || 
                       (s.customer || '').toLowerCase().includes((searchRep || '').toLowerCase());
      const matchDate = s.createdAt && (typeof s.createdAt === 'string' ? s.createdAt : new Date(s.createdAt).toISOString()).startsWith(searchDate);
      return matchRep && matchDate;
  });

  // Calculate Map center
  const mapLocations = filteredSales
      .map(s => parseLocation(s.locationStr))
      .filter(l => l !== null) as {lat: number, lng: number}[];
  
  const defaultCenter = mapLocations.length > 0 ? [mapLocations[0].lat, mapLocations[0].lng] : [7.8731, 80.7718]; // SL center
  
  // Group by Rep for polylines
  const groupedLocations: Record<string, {lat: number, lng: number}[]> = {};
  filteredSales.forEach(s => {
      const loc = parseLocation(s.locationStr);
      if (loc && s.repId) {
          if (!groupedLocations[s.repId]) groupedLocations[s.repId] = [];
          groupedLocations[s.repId].push({lat: loc.lat, lng: loc.lng});
      }
  });

  return (
    <div className="space-y-8">
      <div>
        <h3 className="font-display text-4xl font-bold text-slate-800 tracking-tight">Rep Routes & Locations</h3>
        <p className="text-slate-500 mt-1">Track where the reps are billing from using GPS coordinates. Helps new reps follow standard routes. Uses OpenStreetMap (No API key needed).</p>
      </div>

      <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Search by Rep ID or Customer..." 
               value={searchRep}
               onChange={e => setSearchRep(e.target.value)}
               className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 focus:ring-2 ring-blue-500/20 transition-all font-medium text-slate-700"
             />
          </div>
          <div className="relative w-full md:w-64">
             <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="date" 
               value={searchDate}
               onChange={e => setSearchDate(e.target.value)}
               className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 focus:ring-2 ring-blue-500/20 transition-all font-medium text-slate-700"
             />
          </div>
          <button onClick={loadSales} className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition shadow-sm">
             Refresh
          </button>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading route data...</div>
        ) : (
          <>
             {/* Map Configuration */}
             <div className="mb-6 h-[400px] w-full rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 relative z-0">
                <MapContainer 
                    center={[7.8731, 80.7718]} 
                    zoom={7} 
                    style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <MapUpdater mapLocations={mapLocations} />
                  
                  {filteredSales.map((sale, idx) => {
                      const loc = parseLocation(sale.locationStr);
                      if (!loc) return null;
                      
                      return (
                          <Marker 
                              key={sale.id || `marker-${idx}`} 
                              position={[loc.lat, loc.lng]}
                          >
                            <Popup>
                                <div className="p-1 min-w-[150px]">
                                   <h4 className="font-bold text-sm text-slate-800">{sale.customer || 'Unknown Shop'}</h4>
                                   <p className="text-xs text-slate-500 mb-2">Time: {new Date(sale.createdAt).toLocaleTimeString()}</p>
                                   <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-1 rounded font-semibold uppercase">Rep: {sale.repId}</span>
                                   <p className="font-bold text-sm mt-3 text-slate-800">Rs. {Number(sale.total || 0).toFixed(2)}</p>
                                </div>
                            </Popup>
                          </Marker>
                      );
                  })}
                  
                  <MapLines groupedLocations={groupedLocations} />

                  {/* Live Rep Locations */}
                  {liveLocations.map((loc, idx) => {
                      const parsed = parseLocation(loc.location);
                      if (!parsed) return null;
                      return (
                          <Marker key={`live-${loc.repId}-${idx}`} position={[parsed.lat, parsed.lng]}>
                             <Popup>
                                <div className="p-1 min-w-[150px]">
                                   <h4 className="font-bold text-sm text-blue-600">LIVE: {loc.repName || loc.repId}</h4>
                                   <p className="text-xs text-slate-500 mb-2">Updated: {new Date(loc.timestamp).toLocaleTimeString()}</p>
                                </div>
                             </Popup>
                          </Marker>
                      )
                  })}

                </MapContainer>
             </div>

             {/* Table */}
             <div className="overflow-x-auto">
               <table className="w-full text-left border-collapse">
                 <thead>
                   <tr className="border-b border-slate-100 text-slate-500 text-sm">
                     <th className="py-4 px-2 font-medium">No.</th>
                     <th className="py-4 px-2 font-medium">Time</th>
                     <th className="py-4 px-2 font-medium">Rep ID</th>
                     <th className="py-4 px-2 font-medium">Customer / Shop</th>
                     <th className="py-4 px-2 font-medium">Value</th>
                     <th className="py-4 px-2 font-medium">Location</th>
                     <th className="py-4 px-2 font-medium">Action</th>
                   </tr>
                 </thead>
                 <tbody>
                   {filteredSales.map((sale, i) => (
                     <tr key={sale.id || i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors group">
                       <td className="py-4 px-2 font-bold text-slate-400">{i + 1}</td>
                       <td className="py-4 px-2 text-sm text-slate-600">
                         {sale.createdAt ? new Date(sale.createdAt).toLocaleTimeString() : 'N/A'}
                       </td>
                       <td className="py-4 px-2 font-medium text-slate-800">
                         {sale.repId}
                       </td>
                       <td className="py-4 px-2 text-slate-600 font-semibold">
                         {sale.customer || 'Unknown'} {sale.mode === 'credit' && <span className="text-xs ml-2 text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">Credit</span>}
                       </td>
                       <td className="py-4 px-2 text-sm font-bold text-slate-700">
                         {sale.total ? `Rs. ${Number(sale.total).toFixed(2)}` : '-'}
                       </td>
                       <td className="py-4 px-2 text-[11px] text-slate-500 font-mono">
                         {sale.locationStr ? sale.locationStr : 'No GPS Data'}
                       </td>
                       <td className="py-4 px-2">
                          {sale.locationStr && (
                             <a 
                                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(sale.locationStr)}`} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="inline-flex items-center text-xs font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors"
                             >
                                <MapPin size={14} className="mr-1.5" /> Google Maps
                             </a>
                          )}
                       </td>
                     </tr>
                   ))}
                   {filteredSales.length === 0 && (
                     <tr>
                       <td colSpan={7} className="py-12 text-center text-slate-400">
                         <UserX className="mx-auto w-8 h-8 opacity-20 mb-3" />
                         No route data found for this date & rep
                       </td>
                     </tr>
                   )}
                 </tbody>
               </table>
             </div>
          </>
        )}
      </div>
    </div>
  );
}
